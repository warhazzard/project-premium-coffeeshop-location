Open Matlab and double click on xxx.mat stored on Booklabs/Lab5/Matlab
You can also directly run the xxx.m code from the Matlab Editor window